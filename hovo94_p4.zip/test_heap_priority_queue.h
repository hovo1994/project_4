#include <cxxtest/TestSuite.h>
#include <iostream>
#include "heap_priority_queue.h"

template class HeapPriorityQueue<int>;

class HeapTests : public CxxTest::TestSuite
{
public:
   void testAdd( void )
   {
     HeapPriorityQueue<int> q;
     q.add(1);
     q.add(2);
     q.remove();
     q.remove();
     // TS_ASSERT();
     TS_ASSERT(q.peek() == 1);
   }

   void testAscDecOrder(void)
   {
   	HeapPriorityQueue<int> q;

   	for (int i = 0; i < 100000; ++i)
   	{
   		q.add(i);
   		TS_ASSERT(q.peek() == i);
   	}

   	for (int i = 100000-1; i < 0; ++i)
   	{
   		q.remove();
   		TS_ASSERT(q.peek() == i);
   	}
   	
   }

   void testInsertRandom(void)
   {
   	HeapPriorityQueue<int> q;
   	int  randoms[12] = { 2, 1000, 3, 17, 50, 20, 400, 50, 10, 32, 23, 45};
   	for (int i = 0; i < 12; ++i)
   	{
   		q.add(randoms[i]);
   		if (i == 0 )
   		{
   			TS_ASSERT(q.peek() == 2);
   		}
   		else
   		{
   			TS_ASSERT(q.peek() == 1000);
   		}
   	}


   }
};
